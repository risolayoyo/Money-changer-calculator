package com.moneychanger.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

class MainActivity : Activity() {

    private lateinit var rows: LinearLayout
    private lateinit var total: TextView
    private lateinit var prefs: android.content.SharedPreferences

    private val currencies = arrayOf(
        "USD", "SGD", "MYR", "THB", "EUR", "AUD", "JPY", "CNY",
        "HKD", "SAR", "KRW", "GBP", "NZD", "CHF", "CAD", "IDR"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("money_changer", MODE_PRIVATE)
        rows = findViewById(R.id.rows)
        total = findViewById(R.id.total)

        purge()
        findViewById<EditText>(R.id.shop).setText(prefs.getString("shop", "MONEY CHANGER"))

        addRow()

        findViewById<Button>(R.id.addRow).setOnClickListener { addRow() }
        findViewById<Button>(R.id.save).setOnClickListener { save() }
        findViewById<Button>(R.id.print).setOnClickListener { printReceipt() }
        findViewById<Button>(R.id.history).setOnClickListener { retentionSettings() }
        findViewById<Button>(R.id.newTx).setOnClickListener { reset() }
    }

    private fun addRow() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 10, 0, 10)
        }

        val title = TextView(this).apply {
            text = "Mata uang ${rows.childCount + 1}"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
        }

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, currencies)

        val amount = EditText(this).apply {
            hint = "Nominal / jumlah, contoh 100 atau 100.000"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
        }

        val rate = EditText(this).apply {
            hint = "Kurs ke IDR, contoh 16.500"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
        }

        val lineTotal = TextView(this).apply {
            text = "Nilai IDR: Rp 0"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
        }

        val del = Button(this).apply { text = "Hapus baris" }

        box.addView(title)
        box.addView(spinner)
        box.addView(amount)
        box.addView(rate)
        box.addView(lineTotal)
        box.addView(del)
        rows.addView(box)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (currencies[position] == "IDR") {
                    rate.setText("1")
                }
                calc()
            }
        }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { calc() }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        amount.addTextChangedListener(watcher)
        rate.addTextChangedListener(watcher)

        del.setOnClickListener {
            rows.removeView(box)
            renumberRows()
            calc()
        }

        calc()
    }

    private fun renumberRows() {
        for (i in 0 until rows.childCount) {
            val box = rows.getChildAt(i) as? LinearLayout ?: continue
            (box.getChildAt(0) as? TextView)?.text = "Mata uang ${i + 1}"
        }
    }

    // Menerima 100000, 100.000, 100,5, 100.000,50, dll.
    private fun num(raw: String): Double {
        var s = raw.trim().replace(" ", "")
        if (s.isEmpty()) return 0.0

        val lastComma = s.lastIndexOf(',')
        val lastDot = s.lastIndexOf('.')

        s = when {
            lastComma >= 0 && lastDot >= 0 -> {
                if (lastComma > lastDot) s.replace(".", "").replace(',', '.')
                else s.replace(",", "")
            }
            lastComma >= 0 -> {
                val decimals = s.length - lastComma - 1
                if (decimals in 1..2) s.replace(',', '.')
                else s.replace(",", "")
            }
            lastDot >= 0 -> {
                val decimals = s.length - lastDot - 1
                if (decimals in 1..2) s
                else s.replace(".", "")
            }
            else -> s
        }
        return s.toDoubleOrNull() ?: 0.0
    }

    private fun money(value: Double): String =
        NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }.format(value)

    private fun number(value: Double): String =
        NumberFormat.getNumberInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 2
            minimumFractionDigits = 0
        }.format(value)

    private fun rowData(): JSONArray {
        val data = JSONArray()
        for (i in 0 until rows.childCount) {
            val box = rows.getChildAt(i) as? LinearLayout ?: continue
            val spinner = box.getChildAt(1) as? Spinner ?: continue
            val amount = box.getChildAt(2) as? EditText ?: continue
            val rate = box.getChildAt(3) as? EditText ?: continue

            val a = num(amount.text.toString())
            val r = num(rate.text.toString())
            if (a <= 0.0) continue

            data.put(JSONObject().apply {
                put("currency", spinner.selectedItem?.toString() ?: "USD")
                put("amount", a)
                put("rate", r)
                put("total_idr", a * r)
            })
        }
        return data
    }

    private fun calc(): Double {
        var sum = 0.0
        for (i in 0 until rows.childCount) {
            val box = rows.getChildAt(i) as? LinearLayout ?: continue
            val amount = box.getChildAt(2) as? EditText ?: continue
            val rate = box.getChildAt(3) as? EditText ?: continue
            val line = box.getChildAt(4) as? TextView ?: continue
            val value = num(amount.text.toString()) * num(rate.text.toString())
            line.text = "Nilai IDR: ${money(value)}"
            sum += value
        }
        total.text = "TOTAL IDR: ${money(sum)}"
        return sum
    }

    private fun save() {
        val data = rowData()
        if (data.length == 0) {
            Toast.makeText(this, "Isi minimal satu mata uang.", Toast.LENGTH_SHORT).show()
            return
        }

        val transactions = JSONArray(prefs.getString("transactions", "[]"))
        transactions.put(JSONObject().apply {
            put("time", System.currentTimeMillis())
            put("shop", findViewById<EditText>(R.id.shop).text.toString())
            put("customer", findViewById<EditText>(R.id.customer).text.toString())
            put("cashier", findViewById<EditText>(R.id.cashier).text.toString())
            put("total", calc())
            put("rows", data)
        })

        prefs.edit()
            .putString("transactions", transactions.toString())
            .putString("shop", findViewById<EditText>(R.id.shop).text.toString())
            .apply()

        Toast.makeText(this, "Transaksi tersimpan.", Toast.LENGTH_SHORT).show()
    }

    private fun purge() {
        val days = prefs.getInt("retention_days", 30)
        if (days <= 0) return
        val cutoff = System.currentTimeMillis() - days * 86_400_000L
        val old = JSONArray(prefs.getString("transactions", "[]"))
        val fresh = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optLong("time") >= cutoff) fresh.put(item)
        }
        prefs.edit().putString("transactions", fresh.toString()).apply()
    }

    private fun retentionSettings() {
        val labels = arrayOf("7 hari", "30 hari", "90 hari", "180 hari", "Tidak otomatis")
        val values = intArrayOf(7, 30, 90, 180, 0)
        val current = prefs.getInt("retention_days", 30)
        val checked = values.indexOf(current).let { if (it >= 0) it else 1 }

        AlertDialog.Builder(this)
            .setTitle("Penyimpanan lokal")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                prefs.edit().putInt("retention_days", values[which]).apply()
                purge()
                dialog.dismiss()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun reset() {
        rows.removeAllViews()
        findViewById<EditText>(R.id.customer).setText("")
        findViewById<EditText>(R.id.cashier).setText("")
        total.text = "TOTAL IDR: Rp 0"
        addRow()
    }

    private fun buildReceiptText(): String {
        val shop = findViewById<EditText>(R.id.shop).text.toString().ifBlank { "MONEY CHANGER" }
        val customer = findViewById<EditText>(R.id.customer).text.toString()
        val cashier = findViewById<EditText>(R.id.cashier).text.toString()
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date())

        val sb = StringBuilder()
        sb.append(shop).append('\n')
        sb.append("================================\n")
        sb.append("STRUK MONEY CHANGER\n")
        sb.append(date).append('\n')
        if (customer.isNotBlank()) sb.append("Pelanggan: ").append(customer).append('\n')
        if (cashier.isNotBlank()) sb.append("Kasir: ").append(cashier).append('\n')
        sb.append("--------------------------------\n")

        val data = rowData()
        for (i in 0 until data.length()) {
            val item = data.getJSONObject(i)
            sb.append(item.optString("currency")).append(" ")
                .append(number(item.optDouble("amount")))
                .append(" x ").append(number(item.optDouble("rate"))).append('\n')
            sb.append("= ").append(money(item.optDouble("total_idr"))).append('\n')
        }

        sb.append("--------------------------------\n")
        sb.append("TOTAL: ").append(money(calc())).append('\n')
        sb.append("================================\n")
        sb.append("Terima kasih\n")
        return sb.toString()
    }

    private fun printReceipt() {
        if (rowData().length == 0) {
            Toast.makeText(this, "Isi transaksi terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print(
                "Struk Money Changer",
                ReceiptPrintAdapter(this, buildReceiptText()),
                null
            )
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Layanan cetak Android tidak tersedia. Periksa Pengaturan > Cetak.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private class ReceiptPrintAdapter(
        private val context: Context,
        private val text: String
    ) : PrintDocumentAdapter() {

        private var attributes: PrintAttributes? = null
        private var pageCount = 1

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback,
            extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback.onLayoutCancelled()
                return
            }

            attributes = newAttributes
            val heightMils = newAttributes.mediaSize?.heightMils ?: 11000
            val heightPt = heightMils * 72f / 1000f
            val linesPerPage = ((heightPt - 60f) / 15f).toInt().coerceAtLeast(1)
            pageCount = ceil(text.split("\n").size.toDouble() / linesPerPage).toInt().coerceAtLeast(1)

            val info = PrintDocumentInfo.Builder("money-changer-receipt.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(pageCount)
                .build()

            callback.onLayoutFinished(info, oldAttributes != newAttributes)
        }

        override fun onWrite(
            pages: Array<PageRange>,
            destination: ParcelFileDescriptor,
            cancellationSignal: CancellationSignal,
            callback: WriteResultCallback
        ) {
            val attrs = attributes ?: PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(PrintAttributes.Resolution("receipt", "Receipt", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build()

            val document = android.print.pdf.PrintedPdfDocument(context, attrs)
            try {
                val allLines = text.split("\n")
                val heightMils = attrs.mediaSize?.heightMils ?: 11000
                val heightPt = heightMils * 72f / 1000f
                val linesPerPage = ((heightPt - 60f) / 15f).toInt().coerceAtLeast(1)

                for (pageIndex in 0 until pageCount) {
                    if (cancellationSignal.isCanceled) {
                        callback.onWriteCancelled()
                        return
                    }

                    val start = pageIndex * linesPerPage
                    val end = minOf(start + linesPerPage, allLines.size)
                    val page = document.startPage(pageIndex + 1)
                    val paint = Paint().apply {
                        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
                        textSize = 10f
                        isAntiAlias = true
                    }

                    var y = 28f
                    for (i in start until end) {
                        page.canvas.drawText(allLines[i], 24f, y, paint)
                        y += 15f
                    }
                    document.finishPage(page)
                }

                document.writeTo(FileOutputStream(destination.fileDescriptor))
                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message ?: "Gagal membuat PDF")
            } finally {
                document.close()
                destination.close()
            }
        }
    }
}
