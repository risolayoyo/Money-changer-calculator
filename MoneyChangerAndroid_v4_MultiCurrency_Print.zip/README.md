# Money Changer Android V4

Fitur:
- Multi-currency dalam satu transaksi.
- Total semua mata uang langsung dijumlahkan ke IDR.
- Parsing nominal Indonesia: 100000, 100.000, 100,5, dan format umum lainnya.
- Tambah/hapus baris mata uang.
- Penyimpanan transaksi lokal.
- Penghapusan otomatis 7/30/90/180 hari atau nonaktif.
- Print struk melalui Android Print Service.
- Print dibuat multi-halaman jika struk panjang.
- Print menggunakan ukuran media dari layanan printer, bukan memaksa A4 saat proses tulis.
- Tidak memerlukan permission internet/Bluetooth.

Contoh:
USD 100 x 16.500 = Rp 1.650.000
SGD 50 x 13.000 = Rp 650.000
MYR 200 x 4.000 = Rp 800.000
TOTAL = Rp 3.100.000

Build:
gradle :app:assembleDebug --no-daemon
