plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="com.moneychanger.app"
    compileSdk=35
    defaultConfig { applicationId="com.moneychanger.app"; minSdk=24; targetSdk=35; versionCode=2; versionName="1.1" }
    compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget="17" }
}
kotlin { jvmToolchain(17) }
