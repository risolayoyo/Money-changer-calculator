Money Changer Android v2 - fixed Java/Kotlin JVM target to 17. Build with GitHub Actions.
