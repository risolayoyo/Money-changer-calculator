# Money Changer Android

Aplikasi Android sederhana untuk kalkulasi beberapa mata uang ke IDR.

## Fitur
- Multi-mata-uang.
- Nominal x kurs = total IDR.
- Penyimpanan transaksi secara lokal di perangkat.
- Retensi otomatis: 7, 30, 90, 180 hari, atau tidak otomatis dihapus.
- Penghapusan lama dijalankan otomatis saat aplikasi dibuka dan ketika pengaturan retensi diubah.
- Tidak memakai server/database online.

## Build
Buka folder ini di Android Studio terbaru, tunggu Gradle sync, lalu pilih:
Build > Build App Bundle(s) / APK(s) > Build APK(s).

Catatan: proyek ini disiapkan sebagai source Android. APK siap-install belum dibangun di lingkungan ini.
