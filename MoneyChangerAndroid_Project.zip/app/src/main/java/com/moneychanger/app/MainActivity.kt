package com.moneychanger.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Typeface
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var rows: LinearLayout
    private lateinit var total: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private val currencies = arrayOf("USD","SGD","MYR","THB","EUR","AUD","JPY","CNY","HKD","SAR","KRW","GBP","NZD","CHF","CAD","IDR")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("money_changer", MODE_PRIVATE)
        rows = findViewById(R.id.rows); total = findViewById(R.id.total)
        purgeOldTransactions()
        addRow()
        findViewById<Button>(R.id.addRow).setOnClickListener { addRow() }
        findViewById<Button>(R.id.save).setOnClickListener { saveTransaction() }
        findViewById<Button>(R.id.history).setOnClickListener { showHistorySettings() }
        findViewById<Button>(R.id.newTx).setOnClickListener { resetForm() }
    }

    private fun addRow() {
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, 8, 0, 4)
        val sp = Spinner(this); sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, currencies)
        val nom = EditText(this); nom.hint = "Nominal asing"; nom.inputType = 2 or 8192
        val rate = EditText(this); rate.hint = "Kurs ke IDR"; rate.inputType = 2 or 8192
        val line = TextView(this); line.text = "Rp 0"; line.textSize = 16f; line.setTypeface(null, Typeface.BOLD)
        val del = Button(this); del.text = "Hapus"
        box.addView(sp); box.addView(nom); box.addView(rate); box.addView(line); box.addView(del)
        rows.addView(box)
        val watcher = object: android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st:Int,c:Int,a:Int) {}
            override fun onTextChanged(s: CharSequence?, st:Int,b:Int,c:Int) { calc() }
            override fun afterTextChanged(e: android.text.Editable?) {}
        }
        nom.addTextChangedListener(watcher); rate.addTextChangedListener(watcher)
        del.setOnClickListener { rows.removeView(box); calc() }
    }

    private fun num(v:String) = v.replace(",","").toDoubleOrNull() ?: 0.0
    private fun money(v:Double):String {
        return NumberFormat.getCurrencyInstance(Locale("id","ID")).apply { maximumFractionDigits=0 }.format(v)
    }
    private fun calc():Double {
        var sum=0.0
        for(i in 0 until rows.childCount) {
            val box=rows.getChildAt(i) as LinearLayout
            val nom=box.getChildAt(2) as EditText
            val rate=box.getChildAt(3) as EditText
            val line=box.getChildAt(4) as TextView
            val v=num(nom.text.toString())*num(rate.text.toString())
            line.text=money(v); sum+=v
        }
        total.text="Total: ${money(sum)}"; return sum
    }
    private fun saveTransaction() {
        val sum=calc()
        val arr=JSONArray(prefs.getString("transactions","[]"))
        val o=JSONObject()
        o.put("time",System.currentTimeMillis())
        o.put("customer",(findViewById<EditText>(R.id.customer)).text.toString())
        o.put("cashier",(findViewById<EditText>(R.id.cashier)).text.toString())
        o.put("total",sum)
        arr.put(o)
        prefs.edit().putString("transactions",arr.toString()).apply()
        Toast.makeText(this,"Transaksi tersimpan di perangkat",Toast.LENGTH_SHORT).show()
    }
    private fun purgeOldTransactions() {
        val days=prefs.getInt("retention_days",30)
        if(days<=0) return
        val cutoff=System.currentTimeMillis()-days*24L*60*60*1000
        val old=JSONArray(prefs.getString("transactions","[]")); val fresh=JSONArray()
        for(i in 0 until old.length()) if(old.getJSONObject(i).optLong("time")>=cutoff) fresh.put(old.getJSONObject(i))
        prefs.edit().putString("transactions",fresh.toString()).apply()
    }
    private fun showHistorySettings() {
        val options=arrayOf("7 hari","30 hari","90 hari","180 hari","Tidak otomatis dihapus")
        val values=intArrayOf(7,30,90,180,0)
        val current=prefs.getInt("retention_days",30)
        var checked=values.indexOf(current); if(checked<0) checked=1
        AlertDialog.Builder(this).setTitle("Penyimpanan lokal")
            .setSingleChoiceItems(options,checked){d,w->
                prefs.edit().putInt("retention_days",values[w]).apply(); purgeOldTransactions(); d.dismiss()
                Toast.makeText(this,"Pengaturan penyimpanan diperbarui",Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Tutup",null).show()
    }
    private fun resetForm() {
        rows.removeAllViews()
        findViewById<EditText>(R.id.customer).setText("")
        findViewById<EditText>(R.id.cashier).setText("")
        addRow(); total.text="Total: Rp 0"
    }
}
